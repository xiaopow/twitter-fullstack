FactoryBot.define do
  factory :user do
    email {'test@test.com'}
    username {'testtest'}
    password {'testtest'}
  end
end
