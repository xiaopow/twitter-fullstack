FactoryBot.define do
  factory :session do
    
  end
end
