FactoryBot.define do
  factory :tweet do
    message {'Test Message'}
  end
end
