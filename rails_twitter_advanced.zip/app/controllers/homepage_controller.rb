class HomepageController < ApplicationController
end
