class FeedsController < ApplicationController
end
