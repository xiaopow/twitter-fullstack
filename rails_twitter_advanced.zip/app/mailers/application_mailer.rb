class ApplicationMailer < ActionMailer::Base
  default from: 'tim@verticalwild.com'
  layout 'mailer'
end
